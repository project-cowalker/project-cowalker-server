module.exports = {
    'key' : 'asdkalsdjwefkewjkfljsvp1212rj13oiru'
};

//JWT 키